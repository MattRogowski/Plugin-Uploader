<?php
/**
 * Plugin Uploader 0.1

 * Copyright 2010 Matthew Rogowski

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 ** http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
**/

if(!defined("IN_MYBB"))
{
	header("HTTP/1.0 404 Not Found");
	exit;
}

$plugins->add_hook("admin_config_action_handler", "pluginuploader_admin_config_action_handler");
$plugins->add_hook("admin_config_permissions", "pluginuploader_admin_config_permissions");
$plugins->add_hook("admin_page_output_nav_tabs_start", "pluginuploader_admin_page_output_nav_tabs_start");
$plugins->add_hook("admin_config_plugins_begin", "pluginuploader_admin_config_plugins_begin");
$plugins->add_hook("admin_config_plugins_plugin_list_plugin", "pluginuploader_admin_config_plugins_plugin_list_plugin");

function pluginuploader_info()
{
	return array(
		'name' => 'Plugin Uploader',
		'description' => 'Allows you to import .zip plugin archives directly and have the files extracted to their correct locations automatically.',
		'website' => 'http://mattrogowski.co.uk',
		'author' => 'MattRogowski',
		'authorsite' => 'http://mattrogowski.co.uk',
		'version' => '0.1',
		'compatibility' => '16*',
		'guid' => 'bf2f8440a92b2c8dc841ec7dc1929ff4'
	);
}

function pluginuploader_install()
{
	global $db, $pluginuploader_uninstall_confirm_override;
	
	// this is so we override the confirmation when trying to uninstall, so we can just run the uninstall code
	$pluginuploader_uninstall_confirm_override = true;
	pluginuploader_uninstall();
	
	if(!$db->table_exists("pluginuploader"))
	{
		$db->write_query("
			CREATE TABLE  " . TABLE_PREFIX . "pluginuploader (
				`pid` SMALLINT(5) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
				`name` VARCHAR(255) NOT NULL UNIQUE KEY,
				`version` VARCHAR(25) NOT NULL ,
				`files` TEXT NOT NULL
			) ENGINE = MYISAM ;
		");
	}
	
	chdir(MYBB_ROOT . "inc/plugins/");
	$plugin_files = glob("*.php");
	
	if(!empty($plugin_files))
	{
		foreach($plugin_files as $plugin_file)
		{
			$plugin_name = substr($plugin_file, 0, -4);
			$info_func = $plugin_name . "_info";
			
			if(!function_exists($info_func))
			{
				require_once MYBB_ROOT . "inc/plugins/" . $plugin_file;
			}
			if(!function_exists($info_func))
			{
				continue;
			}
			
			$info = $info_func();
			
			$insert = array(
				"name" => $db->escape_string($plugin_name),
				"version" => $db->escape_string($info['version'])
			);
			$db->insert_query("pluginuploader", $insert);
		}
	}
	
	change_admin_permission("config", "pluginuploader", 1);
}

function pluginuploader_is_installed()
{
	global $db;
	
	return $db->table_exists("pluginuploader");
}

function pluginuploader_uninstall()
{
	global $mybb, $db, $pluginuploader_uninstall_confirm_override;
	
	// this is a check to make sure we want to uninstall
	// if 'No' was chosen on the confirmation screen, redirect back to the plugins page
	if($mybb->input['no'])
	{
		admin_redirect("index.php?module=config-plugins");
	}
	else
	{
		// there's a post request so we submitted the form and selected yes
		// or the confirmation is being overridden by the installation function; this is for when pluginuploader_uninstall() is called at the start of pluginuploader_install(), we just want to execute the uninstall code at this point
		if($mybb->request_method == "post" || $pluginuploader_uninstall_confirm_override === true)
		{
			if($db->table_exists("pluginuploader"))
			{
				$db->drop_table("pluginuploader");
			}
		}
		// need to show the confirmation
		else
		{
			global $lang, $page;
			
			$lang->load("config_pluginuploader");
			
			$page->output_confirm_action("index.php?module=config-plugins&action=deactivate&uninstall=1&plugin=pluginuploader&my_post_key={$mybb->post_code}", $lang->pluginuploader_uninstall_warning);
		}
	}
}

function pluginuploader_activate()
{
	
}

function pluginuploader_deactivate()
{
	
}

function pluginuploader_admin_config_action_handler($actions)
{
	$actions['pluginuploader'] = array(
		"active" => "pluginuploader",
		"file" => "pluginuploader.php"
	);
	
	return $actions;
}

function pluginuploader_admin_config_permissions($admin_permissions)
{
	global $lang;
	
	$lang->load("config_pluginuploader");
	
	$admin_permissions['pluginuploader'] = $lang->can_upload_plugins;
	
	return $admin_permissions;
}

function pluginuploader_admin_page_output_nav_tabs_start($tabs)
{
	global $lang;
	
	$lang->load("config_pluginuploader");
	
	if(array_key_exists("plugins", $tabs) && array_key_exists("update_plugins", $tabs) && array_key_exists("browse_plugins", $tabs))
	{
		$tabs['upload_plugin'] = array(
			'title' => $lang->pluginuploader_upload_plugin,
			'link' => "index.php?module=config-pluginuploader",
			'description' => $lang->pluginuploader_upload_plugin_desc
		);
	}
}

function pluginuploader_admin_config_plugins_begin()
{
	global $mybb, $db, $cache, $lang, $plugins;
	
	$lang->load("config_pluginuploader");
	
	if($mybb->input['action'] == "do_delete")
	{
		if(!verify_post_check($mybb->input['my_post_key']))
		{
			flash_message($lang->invalid_post_verify_key2, 'error');
			admin_redirect("index.php?module=config-plugins");
		}
		
		if($mybb->input['no'])
		{
			admin_redirect("index.php?module=config-plugins");
		}
		
		$plugin_name = $mybb->input['plugin'];
		if($plugin_name)
		{
			$query = $db->simple_select("pluginuploader", "files", "name = '" . $db->escape_string($plugin_name) . "'");
			if($db->num_rows($query) == 1 || file_exists(MYBB_ROOT . "inc/plugins/" . $plugin_name . ".php"))
			{
				$info_func = $plugin_name . "_info";
				$deactivate_func = $plugin_name . "_deactivate";
				$uninstall_func = $plugin_name . "_uninstall";
				if(!function_exists($info_func))
				{
					// plugin isn't currently active, otherwise the info function would be available, but include it anyway to check for an uninstall function
					require_once MYBB_ROOT . "inc/plugins/" . $plugin_name . ".php";
				}
				
				if(function_exists($deactivate_func))
				{
					$deactivate_func();
				}
				if(function_exists($uninstall_func))
				{
					$uninstall_func();
				}
				$plugins_cache = $cache->read("plugins");
				$active_plugins = $plugins_cache['active'];
				unset($active_plugins[$plugin_name]);
				$plugins_cache['active'] = $active_plugins;
				$cache->update("plugins", $plugins_cache);
				
				$errors = array();
				if($db->num_rows($query) == 1)
				{
					$files = $db->fetch_field($query, "files");
					$files = unserialize($files);
					foreach($files as $file)
					{
						if(is_dir(MYBB_ROOT . $file))
						{
							my_rmdir(MYBB_ROOT . $file);
							if(is_dir(MYBB_ROOT . $file))
							{
								$errors[] = "./" . $file;
							}
						}
						else
						{
							if(file_exists(MYBB_ROOT . $file))
							{
								if(!@unlink(MYBB_ROOT . $file))
								{
									$errors[] = "./" . $file;
								}
							}
						}
					}
					
					$db->delete_query("pluginuploader", "name = '" . $db->escape_string($plugin_name) . "'");
				}
				elseif(file_exists(MYBB_ROOT . "inc/plugins/" . $plugin_name . ".php"))
				{
					if(!@unlink(MYBB_ROOT . "inc/plugins/" . $plugin_name . ".php"))
					{
						$errors[] = "./inc/plugins/" . $plugin_name . ".php";
					}
				}
				
				if(!empty($errors))
				{
					$errors = "<li>" . implode("</li><li>", $errors) . "</li>";
					flash_message($lang->sprintf($lang->pluginuploader_delete_errors, $errors), 'error');
					admin_redirect("index.php?module=config-plugins");
				}
				else
				{
					flash_message($lang->pluginuploader_delete_success, 'success');
					admin_redirect("index.php?module=config-plugins");
				}
			}
			else
			{
				flash_message($lang->pluginuploader_delete_invalid_plugin, 'error');
				admin_redirect("index.php?module=config-plugins");
			}
		}
		else
		{
			flash_message($lang->pluginuploader_delete_invalid_plugin, 'error');
			admin_redirect("index.php?module=config-plugins");
		}
	}
	elseif($mybb->input['action'] == "delete")
	{
		global $db, $lang, $page;
		
		$lang->load("config_pluginuploader");
		
		$plugin = $mybb->input['plugin'];
		$delete_message = "";
		
		$query = $db->simple_select("pluginuploader", "files", "name = '" . $db->escape_string($plugin) . "'");
		if($db->num_rows($query) == 1)
		{
			$files = $db->fetch_field($query, "files");
			if(!empty($files))
			{
				$delete_message = $lang->pluginuploader_delete_warning;
			}
		}
		if(!$delete_message)
		{
			$delete_message = $lang->pluginuploader_delete_warning_no_files;
		}
		
		$page->output_confirm_action("index.php?module=config-plugins&action=do_delete&plugin=" . $mybb->input['plugin'] . "&my_post_key={$mybb->post_code}", $delete_message);
	}
}

function pluginuploader_admin_config_plugins_plugin_list_plugin()
{
	global $mybb, $lang, $table, $plugin_info, $codename;
	
	$lang->load("config_pluginuploader");
	
	if($codename != "pluginuploader")
	{
		$table->construct_cell("<a href=\"index.php?module=config-plugins&amp;action=delete&amp;plugin={$codename}&amp;my_post_key={$mybb->post_code}\">{$lang->delete}</a>", array("class" => "align_center", "width" => 150));
	}
	else
	{
		$table->construct_cell("&nbsp;", array("class" => "align_center", "width" => 150));
	}
}

function my_rmdir($dir)
{
	if(is_dir($dir))
	{
		$objects = scandir($dir);
		foreach($objects as $object)
		{
			if($object != "." && $object != "..")
			{
				if(is_dir($dir . "/" . $object))
				{
					my_rmdir($dir . "/" . $object);
				}
				else
				{
					unlink($dir . "/" . $object);
				}
			}
			reset($objects);
		}
		rmdir($dir);
	}
}
?>