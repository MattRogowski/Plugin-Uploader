Name: Plugin Uploader
Description: Allows you to import .zip plugin archives directly and have the files extracted to their correct locations automatically.
Website: http://mattrogowski.co.uk
Author: MattRogowski
Authorsite: http://mattrogowski.co.uk
Version: 0.2
Compatibility: 1.6.x
Files: 3
Database changes: 1 new table.

To Install:
Upload ./inc/plugins/pluginuploader.php to ./inc/plugins/
Upload ./admin/modules/config/pluginuploader.php to ./admin/modules/config/
Upload ./inc/languages/english/admin/config_pluginuploader.lang.php to ./inc/languages/english/admin/
Create folder 'temp' in ./inc/plugins/ and CHMOD to 777.
Optional (but highly recommended) core file edit: Upload ./admin/modules/config/plugins.php to ./admin/modules/config/
Go to ACP > Plugins > Install and Activate
Go to ACP > Configuration > Plugins > Upload Plugin

Information:
This plugin will allow you to import a plugin .zip file directly to the ACP and have the files moved to their correct locations.

Allows you to delete all the files for a plugin (if the plugin was uploaded with this plugin uploader).

Supports uploading an upgraded/newer version of a plugin.

Offers not to upload non-PHP root files to save clutter.

Change Log:
27/11/10 - v0.1 -> Initial beta release.

02/12/10 - v0.1 -> v0.2 -> Fixed bug where you may have got a blank page or PHP error when installing the plugin. Fixed bug where the tab for the Plugin Uploader wouldn't show on the Sharepoint theme and some other ACP themes. Fixed bug where the plugins list would be broken if the plugin was deactivated. Fixed bug where you'd get a PHP error if the ZipArchive class is not available. Fixed bug where plugins could run on the page showing information about the plugin. Fixed bug where not all language files would be loaded for the page showing information about the plugin. Tweaked how list of files in the plugin package is collected and stored. Warning for deleting a plugin will now show which files will be deleted. To upgrade, reupload ./inc/plugins/pluginuploader.php, ./admin/modules/config/pluginuploader.php, ./inc/languages/english/admin/config_pluginuploader.lang.php, and (optional core file edit) ./admin/modules/config/plugins.php