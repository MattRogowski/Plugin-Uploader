<?php
/**
 * Plugin Uploader 0.4.2 - Admin Language File

 * Copyright 2010 Matthew Rogowski

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 ** http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
**/

$l['pluginuploader'] = "Plugin Uploader";
$l['pluginuploader_upload_plugin'] = "Upload Plugin";
$l['pluginuploader_upload_plugin_desc'] = "Upload a .zip plugin archive.";
$l['pluginuploader_plugin'] = "Plugin Archive";
$l['pluginuploader_plugin_desc'] = "Browse for the plugin to upload. It must be a .zip archive. <strong>Note: <span style=\"color: red;\">This will not be able to upload every plugin package.</span></strong> If it is not packed in a certain way it will not be able to put the files in the correct location.";
$l['pluginuploader_plugin_name'] = "Plugin Name";
$l['pluginuploader_plugin_version'] = "Plugin Version";
$l['pluginuploader_plugin_description'] = "Plugin Description";
$l['pluginuploader_plugin_screenshots'] = "Plugin Screenshots";
$l['pluginuploader_plugin_screenshots_desc'] = "Click to enlarge.";
$l['pluginuploader_install_activate'] = "Install and/or Activate??";
$l['pluginuploader_install_activate_desc'] = "Do you want to automatically install and/or activate this plugin after it has been uploaded??";
$l['pluginuploader_activate'] = "Activate plugin??";
$l['pluginuploader_activate_desc'] = "Do you want to automatically activate this plugin??";
$l['pluginuploader_deactivate'] = "Deactivate Plugin??";
$l['pluginuploader_deactivate_desc'] = "<span style=\"color: red;\"><strong>The plugin you're uploading is already activated and running on your forum.</strong></span> In order to continue, it needs to be deactivated.<br /><br /><strong>Note: This could cause some data loss.</strong> Depending on how this plugin is written, deactivating may remove any settings/templates the plugin added, but re-activating will add them back (with their default values/contents). Deactivating may also undo any template edits the plugin made, but re-activating should make the change again. You should not lose any information stored in the database by doing this. You will be able to re-activate the plugin after it has been re-imported.<br /><br />If you choose not to deactivate, you will not be able to continue importing the plugin.";
$l['pluginuploader_import_non_php_root_files'] = "Import non PHP root files??";
$l['pluginuploader_import_non_php_root_files_desc'] = "This plugin comes with files in the root folder that are not PHP files. These are probably documentation/example files that are not used by the plugin and won't affect it working, so it is recommended not to import these files. However, if these files are needed for the plugin to work, you can upload this plugin again and set this option to Yes to import them.";
$l['can_upload_plugins'] = "Can upload plugins??";

$l['pluginuploader_error_no_ziparchive_class'] = "Sorry, your host does not have the ability to extract .zip archives.";
$l['pluginuploader_error_upload'] = "Could not open .zip archive.";
$l['pluginuploader_error_temp_dir'] = "Could not create a temporary plugin folder in ./inc/plugins/temp/. Please make sure it exists and is CHMOD to 777.";
$l['pluginuploader_error_extract'] = "Could not extract archive to temporary plugin folder. Please try again.";
$l['pluginuploader_error_path'] = "Could not work out plugin file structure.";
$l['pluginuploader_error_plugin_file'] = "Could not find main plugin file.";
$l['pluginuploader_error_plugin_pluginuploader'] = "Hold on a minute, you can't use this plugin uploader to try and upload a copy of this plugin. That's even worse than trying to divide by zero. Move along now, nothing to see here. You're going to have to upload the files for this plugin the good old fashioned way, sorry, but well done for trying.";
$l['pluginuploader_plugin_exists'] = "<span style=\"color: red;\"><strong>Note: This plugin is already uploaded to your forum.</strong></span>";
$l['pluginuploader_new_version_warning'] = "<span style=\"color: red;\"><strong>A newer version of {1} is available.</strong></span><br /><br />It has been detected that a newer version of {1} is available on the MyBB Mods site.<br /><br />Your version: {2}<br />Available version: {3}<br /><br />You can download the new version here: <a href=\"http://mods.mybb.com/view/{4}\">http://mods.mybb.com/view/{4}</a><br /><br />When you have downloaded it, you can import the new zip archive.";
$l['pluginuploader_plugin_same_version'] = "You are uploading the same version of the plugin that you have currently got installed.";
$l['pluginuploader_plugin_new_version'] = "You are uploading a newer version of the plugin than the version you have currently got installed.";
$l['pluginuploader_plugin_old_version'] = "<strong>You are uploading an <span style=\"color: red;\">older version</span> of the plugin than the version you have currently got installed.</strong>";
$l['pluginuploader_plugin_old_version_2'] = "<span style=\"color: red;\"><strong>Warning: This is an older version of the plugin than the version you have currently got installed.</strong></span>";
$l['pluginuploader_plugin_upgrade_warning'] = "If you continue, it will reimport <strong>all</strong> the files for this plugin, which will overwrite any edits you have made to them. It will also add any new/missing files.";
$l['pluginuploader_error_move_files'] = "There was an error importing this plugin. The following files could not be moved to their proper locations:<br /><ul>{1}</ul>You can either try importing the plugin again, or upload these files manually.";
$l['pluginuploader_error_move_external_files'] = "There was an error importing this plugin. This plugin has extra files that need to be included in order to run the info function. These files could not be moved to their proper locations:<br /><ul>{1}</ul>You can either try importing the plugin again, or upload these files manually.";
$l['pluginuploader_delete_warning'] = "<span style=\"color: red;\"><strong>WARNING</strong></span><br /><br />If you continue, this process will <strong>deactivate</strong> and (if applicable) <strong>uninstall</strong> this plugin, and <strong>delete all files</strong> for it.<br /><br /><strong>It will (try to) completely remove all traces of it from your forum.</strong><br /><br />The following files will be deleted:<br /><ul>{1}</ul>If any of these files are core files, please make sure to upload them again from a fresh download of your version of MyBB.<br /><br />Are you sure you wish to continue??";
$l['pluginuploader_delete_warning_no_files'] = "<span style=\"color: red;\"><strong>WARNING</strong></span><br /><br />If you continue, this process will <strong>deactivate</strong> and (if applicable) <strong>uninstall</strong> this plugin.<br /><br />As the files for this plugin were not uploaded by the plugin uploader, only the main plugin file can be deleted. Other files for this plugin will be left where they are.<br /><br />If you would like to delete all the files for this plugin, you can import the plugin again via the plugin uploader, and then choose to delete it from the plugin list again.<br /><br />Are you sure you wish to continue??";
$l['pluginuploader_delete_invalid_plugin'] = "Could not delete plugin. Invalid plugin specified.";
$l['pluginuploader_delete_errors'] = "The following files could not be deleted:<br /><ul>{1}</ul>";
$l['pluginuploader_success'] = "Plugin uploaded successfully. You can now install and/or activate it below.";
$l['pluginuploader_delete_success'] = "Plugin deleted successfully.";

$l['delete'] = "Delete";
$l['submit'] = "Submit";
$l['pluginuploader_import_plugin'] = "Import Plugin";
$l['pluginuploader_activated'] = "activated";
$l['pluginuploader_deactivated'] = "deactivated";

$l['pluginuploader_install_password_message_title'] = "WARNING - IMPORTANT - PLEASE READ THIS TO THE END";
$l['pluginuploader_install_password_message'] = "This plugin allows you to import a plugin and have the files extracted to their proper locations. However, it is impossible for the uploader to check whether the files in the zip are an actual plugin, or malicious files intended to do harm to your forum. Because of this, it is physically possible for someone who gains admin access to upload potentially malicious files to your server via the plugin uploader. This is not a flaw in the plugin uploader itself, but merely an unavoidable flaw in the concept of allowing plugin files to be uploaded and imported via the Admin Control Panel rather than via FTP.<br /><br />For this reason, by default, other admins will not have the ability to upload plugins, and you should only give other admin access to it if you absolutely trust them and they absolutely need it.<br /><br />A password is also required to be entered when uploading a plugin. This is so that even if somebody gains access to an admin account that has the ability to upload plugins, they will not be able to upload a plugin as they will not know the password.<br /><br />The password you create <strong>SHOULD NOT</strong> be the same as your admin password, and it <strong>SHOULD NOT</strong> be the same as the database password. You <strong>SHOULD NOT</strong> post this password anywhere. This includes the Administrator Notes in the ACP, your Personal Notepad in your User CP, or any forums, even if they are private forums. <strong>Remember, this password is to stop people uploading malicious files to your server, and should be kept as secret as your database details and FTP details.</strong><br /><br />Please enter the password you want to use below, and it will be stored in the database. Any Super Administrator will be able to change this password at any time, as long as they know the current password. This password will also be required when uninstalling the plugin.";
$l['pluginuploader_install_password_message_not_super_admin'] = "As you are not a super admin, you are not able to set a password for the plugin uploader. Please contact a super administrator.";
$l['pluginuploader_password'] = "Password";
$l['pluginuploader_password_desc'] = "Enter the password you want to use for the plugin uploader.";
$l['pluginuploader_password_confirm'] = "Confirm Password";
$l['pluginuploader_password_confirm_desc'] = "Enter the password again.";
$l['pluginuploader_password_current'] = "Current Password";
$l['pluginuploader_password_current_desc'] = "Enter the current password.";
$l['pluginuploader_password_upload_desc'] = "Enter the plugin uploader password to be able to upload a plugin.";
$l['pluginuploader_password_not_super_admin'] = "You cannot change the password as you are not a super admin.";
$l['pluginuploader_password_incorrect'] = "The password you have entered is incorrect. Please try again.";
$l['pluginuploader_password_current_incorrect'] = "The current password you have entered is incorrect. Please try again.";
$l['pluginuploader_password_not_same'] = "The passwords you have entered do not match. Please try again.";
$l['pluginuploader_password_empty'] = "You cannot enter an empty password. Please try again.";
$l['pluginuploader_password_updated'] = "Password updated successfully.";
$l['pluginuploader_password_change'] = "Change password.";
$l['pluginuploader_password_change_title'] = "Change Plugin Uploader Password";
$l['pluginuploader_uninstall_message_title'] = "Uninstall the Plugin Uploader";
$l['pluginuploader_uninstall_warning'] = "To be able to uninstall the Plugin Uploader, you must enter the password that you use to upload plugins. This is to prevent people uninstalling and reinstalling the plugin to reset the password.";
$l['pluginuploader_uninstall_password_incorrect'] = "The plugin could not be uninstalled as you entered an incorrect password. Please try again.";
?>