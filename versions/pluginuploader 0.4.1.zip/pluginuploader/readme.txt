Name: Plugin Uploader
Description: Allows you to import .zip plugin archives directly and have the files extracted to their correct locations automatically.
Website: http://mattrogowski.co.uk
Author: MattRogowski
Authorsite: http://mattrogowski.co.uk
Version: 0.4.1
Compatibility: 1.6.x
Files: 3 (plus 1 optional core file edit)
Database changes: 1 new table.

To Install:
Upload ./inc/plugins/pluginuploader.php to ./inc/plugins/
Upload ./admin/modules/config/pluginuploader.php to ./admin/modules/config/
Upload ./inc/languages/english/admin/config_pluginuploader.lang.php to ./inc/languages/english/admin/
Create folder 'temp' in ./inc/plugins/ and CHMOD to 777.
Optional (but highly recommended) core file edit: Upload ./admin/modules/config/plugins.php to ./admin/modules/config/
Go to ACP > Plugins > Install and Activate
Go to ACP > Configuration > Plugins > Upload Plugin

Information:
This plugin will allow you to import a plugin .zip file directly to the ACP and have the files moved to their correct locations.

For security, a password is required when uploading a plugin.

It will try and show you screenshots of the plugin if any have been provided.

If the plugin is from the MyBB Mods site, it will check that the version you are uploading is the latest version, and if it's not, will give you the download URL for the newer version.

Allows you to delete all the files for a plugin (if the plugin was uploaded with this plugin uploader).

Supports uploading an upgraded/newer version of a plugin.

Offers not to upload non-PHP root files to save clutter.

Change Log:
27/11/10 - v0.1 -> Initial beta release.
02/12/10 - v0.1 -> v0.2 -> Fixed bug where you may have got a blank page or PHP error when installing the plugin. Fixed bug where the tab for the Plugin Uploader wouldn't show on the Sharepoint theme and some other ACP themes. Fixed bug where the plugins list would be broken if the plugin was deactivated. Fixed bug where you'd get a PHP error if the ZipArchive class is not available. Fixed bug where plugins could run on the page showing information about the plugin. Fixed bug where not all language files would be loaded for the page showing information about the plugin. Tweaked how list of files in the plugin package is collected and stored. Warning for deleting a plugin will now show which files will be deleted. To upgrade, reupload ./inc/plugins/pluginuploader.php, ./admin/modules/config/pluginuploader.php, ./inc/languages/english/admin/config_pluginuploader.lang.php, and (optional core file edit) ./admin/modules/config/plugins.php
09/12/10 - v0.2 -> v0.3 -> Fixed bug were you'd get PHP errors on the plugins page if you have other plugins uploaded, but this is the first plugin you activated. Tweaked how it searches for the plugin file root. If the plugin is from the MyBB Mods site, it will now check the plugin version and tell you if it's out of date. Import page that shows information about the plugin will now try and find screenshots and display them as thumbnails on the information page. To upgrade, reupload ./inc/plugins/pluginuploader.php, ./admin/modules/config/pluginuploader.php, and ./inc/languages/english/admin/config_pluginuploader.lang.php
09/12/10 - v0.3 -> v0.3.1 -> Fixed bug were you'd get PHP errors if the plugin had external files as the file path was wrong. To upgrade, reupload ./inc/plugins/pluginuploader.php and ./admin/modules/config/pluginuploader.php
19/01/11 - v0.3.1 -> v0.4 -> Added a password check when uploading plugins. To upgrade, reupload ./inc/plugins/pluginuploader.php, ./admin/modules/config/pluginuploader.php, and ./inc/languages/english/admin/config_pluginuploader.lang.php. More information on this is available here: http://mattrogowski.co.uk/plugins/thread-15.html
19/01/11 - v0.4 -> v0.4.1 -> Fixed a bug where choosing to activate a plugin after importing would redirect back to the plugin uploader page. Fixed a bug where you'd get an error saying the password was wrong after choosing to import the plugin. To upgrade, reupload ./inc/plugins/pluginuploader.php and ./admin/modules/config/pluginuploader.php.

Copyright 2010 Matthew Rogowski

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 ** http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.